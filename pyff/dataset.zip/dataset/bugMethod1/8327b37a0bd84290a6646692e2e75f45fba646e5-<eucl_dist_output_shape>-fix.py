

def eucl_dist_output_shape(shapes):
    (shape1, shape2) = shapes
    return (shape1[0], 1)
