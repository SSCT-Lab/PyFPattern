

def get_browser_sdk_version_versions():
    return ['latest', '4.x', DEFAULT_VERSION]
